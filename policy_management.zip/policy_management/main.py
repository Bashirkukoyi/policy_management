from policyholder import Policyholder
from product import Product
from payment import PaymentManager

# Create products
product1 = Product(product_id=1, name="Health Insurance", premium=500, coverage_details="Full Coverage")
product2 = Product(product_id=2, name="Life Insurance", premium=1000, coverage_details="Full Coverage with Benefits")

# Create policyholders
policyholder1 = Policyholder(policyholder_id=1, name="Bashir Kukoyi", contact="bash.k@example.com")
policyholder2 = Policyholder(policyholder_id=2, name="Fasasi Kukoyi", contact="fas.k@example.com")

# Register policyholders
policyholder1.register()
policyholder2.register()

# Process payments for policyholders
payment_manager = PaymentManager()
payment_manager.process_payment(policyholder1, product1.premium)
payment_manager.process_payment(policyholder2, product2.premium)

# Display policyholder details
print("\nPolicyholder Details:")
print(policyholder1)
print(policyholder2)

# Apply additional functionalities
policyholder1.suspend()
payment_manager.send_reminder(policyholder2)
payment_manager.apply_penalty(policyholder2, 50)

# Display updated policyholder details
print("\nUpdated Policyholder Details:")
print(policyholder1)
print(policyholder2)
