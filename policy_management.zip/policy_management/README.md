# Policy Management System

## Description
This project is a simple policy management system for an insurance company. It includes functionalities for managing policyholders, products, and payments.

## Installation
1. Clone the repository:
2. Navigate to the project directory:
3. Install the required packages:

## Usage
1. Run the main script:

## Features
- Register, suspend, and reactivate policyholders.
- Process payments, send payment reminders, and apply penalties.
- Create, update, and remove/suspend policy products.

## Files
- `policyholder.py`: Contains the `Policyholder` class.
- `product.py`: Contains the `Product` class.
- `payment.py`: Contains the `Payment` and `PaymentManager` classes.
- `main.py`: Demonstrates the usage of the classes.
- `README.md`: Project documentation.
- `requirements.txt`: List of dependencies.
