from datetime import datetime

class Payment:
    def __init__(self, payment_id, amount, date=None):
        self.payment_id = payment_id
        self.amount = amount
        self.date = date if date else datetime.now()
    
    def __str__(self):
        return f"Payment ID: {self.payment_id}, Amount: {self.amount}, Date: {self.date}"
    
class PaymentManager:
    def process_payment(self, policyholder, amount):
        payment = Payment(payment_id=len(policyholder.payments) + 1, amount=amount)
        policyholder.add_payment(payment)
        print(f"Payment of {amount} processed for policyholder {policyholder.name}.")
    
    def send_reminder(self, policyholder):
        print(f"Reminder sent to policyholder {policyholder.name}.")
    
    def apply_penalty(self, policyholder, penalty_amount):
        penalty_payment = Payment(payment_id=len(policyholder.payments) + 1, amount=penalty_amount)
        policyholder.add_payment(penalty_payment)
        print(f"Penalty of {penalty_amount} applied to policyholder {policyholder.name}.")
