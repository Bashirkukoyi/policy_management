class Product:
    def __init__(self, product_id, name, premium, coverage_details):
        self.product_id = product_id
        self.name = name
        self.premium = premium
        self.coverage_details = coverage_details
        self.status = 'active'
    
    def update(self, name=None, premium=None, coverage_details=None):
        if name:
            self.name = name
        if premium:
            self.premium = premium
        if coverage_details:
            self.coverage_details = coverage_details
        print(f"Product {self.product_id} has been updated.")
    
    def remove(self):
        self.status = 'inactive'
        print(f"Product {self.name} has been removed/suspended.")

    def __str__(self):
        return f"ID: {self.product_id}, Name: {self.name}, Premium: {self.premium}, Coverage: {self.coverage_details}, Status: {self.status}"
