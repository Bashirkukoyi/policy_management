class Policyholder:
    def __init__(self, policyholder_id, name, contact):
        self.policyholder_id = policyholder_id
        self.name = name
        self.contact = contact
        self.status = 'active'
        self.payments = []

    def register(self):
        print(f"Policyholder {self.name} registered successfully.")
    
    def suspend(self):
        self.status = 'suspended'
        print(f"Policyholder {self.name} has been suspended.")
    
    def reactivate(self):
        self.status = 'active'
        print(f"Policyholder {self.name} has been reactivated.")
    
    def add_payment(self, payment):
        self.payments.append(payment)

    def __str__(self):
        return f"ID: {self.policyholder_id}, Name: {self.name}, Contact: {self.contact}, Status: {self.status}, Payments: {[str(payment) for payment in self.payments]}"
